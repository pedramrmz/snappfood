import 'containers/commentContainer.dart';
import 'containers/customerContainer.dart';
import 'containers/foodCategoryContainer.dart';
import 'containers/foodContainer.dart';
import 'containers/orderContainer.dart';
import 'containers/regionContainer.dart';
import 'containers/restaurantCategoryContainer.dart';
import 'containers/restaurantsContainer.dart';
import 'entities/restaurant.dart';

class Service {
  static final Service _instance = Service._internal();

  Restaurant currentRestaurant;
  RestaurantsContainer restaurants = new RestaurantsContainer();
  RestaurantCategoryContainer restaurantCategories =
      new RestaurantCategoryContainer();
  FoodCategoryContainer foodCategories = new FoodCategoryContainer();
  FoodContainer foods = new FoodContainer();
  CustomerContainer customers = new CustomerContainer();
  CommentContainer comments = new CommentContainer();
  OrderContainer orders = new OrderContainer();
  RegionContainer regions = new RegionContainer();

  factory Service() => _instance;

  Service._internal() {
    // setup
  }
}
