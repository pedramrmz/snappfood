import 'package:flutter/material.dart';

import '../entities/order.dart';
import '../entities/orderItem.dart';
import '../func.dart';
import '../service.dart';

class ReportOrderCountScreen extends StatefulWidget {
  const ReportOrderCountScreen({Key key}) : super(key: key);

  @override
  _ReportOrderCountScreenState createState() => _ReportOrderCountScreenState();
}

class _ReportOrderCountScreenState extends State<ReportOrderCountScreen> {
  Service _service = Service();
  List<Order> _orders = [];
  List<DateRange> _dateRanges = [];
  int ordersCount = 0;
  double ordersPrice = 0;
  int _selectedTagIndex = 0;

  @override
  void initState() {
    _dateRanges.add(DateRange('امروز', getStartOfDate(DateTime.now())));
    _dateRanges.add(DateRange(
        'دیروز', getStartOfDate(DateTime.now().subtract(Duration(days: 1)))));
    _dateRanges.add(DateRange('هفته گذشته',
        getStartOfDate(DateTime.now().subtract(Duration(days: 7)))));
    _dateRanges.add(DateRange('ماه گذشته',
        getStartOfDate(DateTime.now().subtract(Duration(days: 30)))));
    _dateRanges.add(DateRange('سال گذشته',
        getStartOfDate(DateTime.now().subtract(Duration(days: 365)))));

    _runFilter();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('گزارش فروش'),
        ),
        body: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _filterDateRanges(),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Card(
                    child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        "گزارش مبلغ فروش",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("عنوان"),
                          Text("تعداد"),
                          Text("مبلغ"),
                        ],
                      ),
                      Divider(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("فروش آنلاین"),
                          Text(ordersCount.toString()),
                          Text(ordersPrice.toString() + " تومان"),
                        ],
                      )
                    ],
                  ),
                )),
              ),
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: ListView.builder(
                    itemCount: _orders.length,
                    itemBuilder: (BuildContext context, int index) {
                      return _orderItem(_orders[index], index);
                    }),
              ))
            ],
          ),
        ));
  }

  _filterDateRanges() {
    return Expanded(
      flex: 0,
      child: Container(
        margin: EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0),
        height: 40,
        child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _dateRanges.length,
            itemBuilder: (BuildContext context, int index) {
              return _dateRangeItem(_dateRanges[index], index);
            }),
      ),
    );
  }

  Widget _dateRangeItem(DateRange dateRang, int index) {
    return TextButton(
      onPressed: () {
        _selectedTagIndex = index;
        _runFilter();
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Text(
          dateRang.title,
          style: new TextStyle(
              color:
                  _selectedTagIndex == index ? Colors.green : Colors.blueGrey),
        ),
      ),
    );
  }

  void _runFilter() {
    _orders = _service.orders.all;
    if (_service.currentRestaurant != null) {
      _orders = _orders
          .where((element) =>
              element.restaurantId == _service.currentRestaurant.id)
          .toList();
    }

    _orders = _orders
        .where((element) => element.orderDateTime
            .isAfter(_dateRanges[_selectedTagIndex].startDate))
        .toList();

    setState(() {
      _orders = _orders;
      ordersCount = _orders.length;
      ordersPrice = 0;
      _orders.forEach((element) {
        ordersPrice += element.orderPrice;
      });
    });
  }

  Widget _orderItem(Order order, int index) {
    TextStyle style = TextStyle(color: Colors.black54, fontSize: 12);

    return Card(
        child: Container(
            padding: EdgeInsets.all(12),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        '#' + order.trackingCode,
                        style: TextStyle(color: Colors.green, fontSize: 12),
                      ),
                      Text(
                        '  -  ',
                        style: style,
                      ),
                      Text(
                        order.customer.firstName +
                            " " +
                            order.customer.lastName,
                        style:
                            TextStyle(color: Colors.deepPurple, fontSize: 14),
                      ),
                      Text(
                        '  -  ',
                        style: style,
                      ),
                      Text(dateFormat(order.orderDateTime,
                          format: "yyyy-MM-dd HH:mm:ss"))
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text('شرح اقلام:', style: style),
                  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: order.items
                          .map((e) =>
                              _orderLineItem(e, order.items.indexOf(e) + 1))
                          .toList()),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'مبلغ کل سفارش:',
                        style: style,
                      ),
                      Text(order.orderPrice.toString() + ' تومان')
                    ],
                  )
                ])));
  }

  Widget _orderLineItem(OrderItem orderItem, int index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text(
                  index.toString(),
                  style: TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Icon(
                  Icons.chevron_right,
                  color: Colors.black54,
                ),
                SizedBox(
                  width: 5,
                ),
                Text(orderItem.food.title),
                SizedBox(
                  width: 5,
                ),
                Text(
                  'تعداد: ' + orderItem.qty.toString(),
                  style: TextStyle(color: Colors.green, fontSize: 11),
                ),
              ],
            ),
            Row(
              children: [
                Text(
                  orderItem.priceTotal.toString() + ' تومان',
                  style: TextStyle(color: Colors.redAccent),
                )
              ],
            )
          ],
        ),
        Divider(),
      ],
    );
  }
}

class DateRange {
  String title;
  DateTime startDate;

  DateRange(this.title, this.startDate);
}
