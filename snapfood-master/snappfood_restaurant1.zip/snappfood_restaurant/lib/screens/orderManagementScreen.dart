import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../entities/order.dart';
import '../entities/orderItem.dart';
import '../func.dart';
import '../service.dart';

class OrderManagementScreen extends StatefulWidget {
  const OrderManagementScreen({Key key}) : super(key: key);

  @override
  _OrderManagementScreenState createState() => _OrderManagementScreenState();
}

class _OrderManagementScreenState extends State<OrderManagementScreen> {
  Service _service = Service();
  List<Order> _orders = [];

  @override
  void initState() {
    _orders = _service.orders.all;
    if (_service.currentRestaurant != null)
      _orders = _orders
          .where((element) =>
              element.restaurantId == _service.currentRestaurant.id)
          .toList();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('سفارشات'),
        ),
        body: Container(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: ListView.builder(
                itemCount: _orders.length,
                itemBuilder: (BuildContext context, int index) {
                  return _orderItem(_orders[index], index);
                }),
          ),
        ));
    ;
  }

  Widget _orderItem(Order order, int index) {
    TextStyle style = TextStyle(color: Colors.black54, fontSize: 12);

    return Card(
        child: Container(
            padding: EdgeInsets.all(12),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        '#' + order.trackingCode,
                        style: TextStyle(color: Colors.green, fontSize: 12),
                      ),
                      Text(
                        '  -  ',
                        style: style,
                      ),
                      Text(
                        order.customer.firstName +
                            " " +
                            order.customer.lastName,
                        style:
                            TextStyle(color: Colors.deepPurple, fontSize: 14),
                      ),
                      Text(
                        '  -  ',
                        style: style,
                      ),
                      Text(dateFormat(order.orderDateTime,
                          format: "yyyy-MM-dd HH:mm:ss"))
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text('شرح اقلام:', style: style),
                  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: order.items
                          .map((e) =>
                              _orderLineItem(e, order.items.indexOf(e) + 1))
                          .toList()),
                  Row(
                    children: [
                      Text(
                        'توضیحات',
                        style: style,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(order.description == null
                          ? 'ندارد'
                          : order.description)
                    ],
                  ),
                  SwitchListTile(
                    title: Text('در حال آماده سازی'),
                    value: order.orderStatus == OrderStatus.preparing ||
                        order.orderStatus == OrderStatus.delivered,
                    onChanged: (bool value) {
                      setState(() {
                        if (value)
                          _orders[index].orderStatus = OrderStatus.preparing;
                        else
                          _orders[index].orderStatus = OrderStatus.received;
                      });
                    },
                    secondary: const Icon(Icons.done),
                  ),
                  SwitchListTile(
                    title: Text('تحویل داده شد'),
                    value: order.orderStatus == OrderStatus.delivered,
                    onChanged: (bool value) {
                      setState(() {
                        if (value)
                          _orders[index].orderStatus = OrderStatus.delivered;
                        else
                          _orders[index].orderStatus = OrderStatus.preparing;
                      });
                    },
                    secondary: const Icon(Icons.done_all),
                  ),
                ])));
  }

  Widget _orderLineItem(OrderItem orderItem, int index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text(
                  index.toString(),
                  style: TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Icon(
                  Icons.chevron_right,
                  color: Colors.black54,
                ),
                SizedBox(
                  width: 5,
                ),
                Text(orderItem.food.title),
              ],
            ),
            Row(
              children: [
                Text(orderItem.qty.toString() + " x", style: TextStyle(color: Colors.redAccent, fontSize: 18),)
              ],
            )
          ],
        ),
        Divider(),
      ],
    );
  }
}
