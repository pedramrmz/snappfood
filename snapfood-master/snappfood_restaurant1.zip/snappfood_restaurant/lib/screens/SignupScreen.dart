import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../containers/restaurantCategoryContainer.dart';
import '../containers/restaurantsContainer.dart';
import '../entities/restaurant.dart';
import '../entities/restaurantCategory.dart';
import '../func.dart';
import '../screens/loginScreen.dart';

class SignupScreen extends StatefulWidget {
  final RestaurantsContainer restaurants;

  const SignupScreen({Key key, this.restaurants}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState(restaurants);
}

class _SignupScreenState extends State<SignupScreen> {
  final titleController = TextEditingController();
  final addressController = TextEditingController();
  final telController = TextEditingController();
  final passwordController = TextEditingController();
  final RestaurantsContainer restaurants;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final RestaurantCategoryContainer restaurantCategoryContainer =
      new RestaurantCategoryContainer();
  RestaurantCategory restaurantCategory;
  bool _obscureText = true;

  _SignupScreenState(this.restaurants);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ثبت نام'),
      ),
      body: Container(
          padding: EdgeInsets.all(60),
          child: Center(
            child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                    child: Column(
                  children: <Widget>[
                    TextFormField(
                        controller: titleController,
                        decoration: InputDecoration(
                            border: const OutlineInputBorder(),
                            labelText: 'نام رستوران',
                            hintText: 'نام رستوران'),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'نام رستوران الزامی است';
                          }
                          return null;
                        }),
                    SizedBox(
                      height: 20,
                    ),
                    TextFormField(
                        controller: addressController,
                        decoration: InputDecoration(
                            border: const OutlineInputBorder(),
                            labelText: 'آدرس رستوران',
                            hintText: 'آدرس رستوران'),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'آدرس رستوران الزامی است';
                          }
                          return null;
                        }),
                    SizedBox(
                      height: 20,
                    ),
                    DropdownButtonFormField(
                        value: restaurantCategory,
                        isExpanded: true,
                        hint: Text('نوع غذا'),
                        onChanged: (RestaurantCategory selected) {
                          setState(() {
                            restaurantCategory = selected;
                          });
                        },
                        validator: (value) {
                          if (value == null) {
                            return 'نوع غذا الزامی است';
                          }
                          return null;
                        },
                        items: restaurantCategoryContainer.all
                            .map<DropdownMenuItem<RestaurantCategory>>(
                                (RestaurantCategory value) {
                          return DropdownMenuItem<RestaurantCategory>(
                            value: value,
                            child: Text(value.title),
                          );
                        }).toList()),
                    SizedBox(
                      height: 20,
                    ),
                    TextFormField(
                        controller: telController,
                        decoration: InputDecoration(
                            border: const OutlineInputBorder(),
                            labelText: 'تلفن',
                            hintText: 'تلفن'),
                        validator: (value) {
                          return validateTel(restaurants, value, true);
                        }),
                    SizedBox(
                      height: 20,
                    ),
                    TextFormField(
                        controller: passwordController,
                        decoration: InputDecoration(
                            border: const OutlineInputBorder(),
                            labelText: 'کلمه عبور',
                            hintText: 'کلمه عبور',
                            suffixIcon: GestureDetector(
                              dragStartBehavior: DragStartBehavior.down,
                              onTap: () {
                                setState(() {
                                  _obscureText = !_obscureText;
                                });
                              },
                              child: Icon(
                                _obscureText
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                            )),
                        obscureText: true,
                        validator: (value) {
                          return validatePassword(value);
                        }),
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: ElevatedButton(
                          onPressed: doSignup, child: Text('ثبت نام')),
                    ),
                  ],
                ))),
          )),
    );
  }

  void doSignup() {
    if (_formKey.currentState.validate()) {
      Restaurant restaurant = new Restaurant(
          title: titleController.text,
          address: addressController.text,
          category: restaurantCategory,
          tel: telController.text,
          password: passwordController.text);
      restaurants.add(restaurant);

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('ثبت نام با موفقیت انجام شد'),
        backgroundColor: Colors.green,
      ));

      Navigator.pop(context);
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => LoginScreen()));
    }
  }
}
