import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../entities/food.dart';
import '../entities/foodCategory.dart';
import '../screens/restaurantMenuScreen.dart';
import '../service.dart';

class FoodEditScreen extends StatefulWidget {
  final Food food;
  final bool editMode;

  const FoodEditScreen({Key key, this.food, this.editMode}) : super(key: key);

  @override
  _FoodEditScreenState createState() => _FoodEditScreenState(food, editMode);
}

class _FoodEditScreenState extends State<FoodEditScreen> {
  Service _service = Service();
  final bool editMode;
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final priceController = TextEditingController();
  FoodCategory _foodCategory;
  bool _available = true;
  final Food food;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  _FoodEditScreenState(this.food, this.editMode);

  @override
  void initState() {
    if (editMode) {
      titleController.text = food.title;
      descriptionController.text = food.description;
      priceController.text = food.price.toString();
      _available = food.available;
      _foodCategory = food.foodCategory;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(editMode ? food.title : 'افزودن محصول'),
        ),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(20),
            child: Center(
                child: Form(
                    key: _formKey,
                    child: Column(children: <Widget>[
                      TextFormField(
                          controller: titleController,
                          decoration: InputDecoration(
                              border: const OutlineInputBorder(),
                              labelText: 'نام محصول',
                              hintText: 'نام محصول'),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'نام محصول الزامی است';
                            }
                            return null;
                          }),
                      SizedBox(
                        height: 20,
                      ),
                      TextFormField(
                        controller: descriptionController,
                        decoration: InputDecoration(
                            border: const OutlineInputBorder(),
                            labelText: 'توضیحات',
                            hintText: 'توضیحات'),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextFormField(
                        controller: priceController,
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[
                          FilteringTextInputFormatter.digitsOnly
                        ],
                        decoration: InputDecoration(
                            border: const OutlineInputBorder(),
                            labelText: 'قیمت',
                            hintText: 'قیمت'),
                        validator: (value) {
                          try {
                            if (value == null || double.parse(value) < 0) {
                              return 'قیمت غذا الزامی است';
                            }
                          } catch (e) {
                            return 'قیمت غذا الزامی است';
                          }

                          return null;
                        },
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      DropdownButtonFormField(
                          value: _foodCategory,
                          isExpanded: true,
                          hint: Text('نوع غذا'),
                          onChanged: (FoodCategory selected) {
                            setState(() {
                              _foodCategory = selected;
                            });
                          },
                          validator: (value) {
                            if (value == null) {
                              return 'نوع غذا الزامی است';
                            }
                            return null;
                          },
                          items: _service.foodCategories.all
                              .map<DropdownMenuItem<FoodCategory>>(
                                  (FoodCategory value) {
                            return DropdownMenuItem<FoodCategory>(
                              value: value,
                              child: Text(value.title),
                            );
                          }).toList()),
                      SizedBox(
                        height: 20,
                      ),
                      SwitchListTile(
                        title: const Text('قابل سفارش'),
                        value: _available,
                        onChanged: (bool value) {
                          setState(() {
                            _available = value;
                          });
                        },
                        secondary: const Icon(Icons.store),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      ElevatedButton(
                          onPressed: _saveOrUpdate,
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Text('ذخیره'),
                          )),
                      SizedBox(
                        height: 20,
                      ),
                      _deleteBtn(),
                    ]))),
          ),
        ));
  }

  void _saveOrUpdate() {
    if (_formKey.currentState.validate()) {
      food.available = _available;
      food.foodCategory = _foodCategory;
      food.title = titleController.text;
      food.description = descriptionController.text;
      food.price = double.parse(priceController.text);

      if (editMode)
        _service.foods.update(food);
      else {
        food.id = _service.foods.all.last.id + 1;
        food.restaurantId = _service.currentRestaurant.id;
        _service.foods.add(food);
      }

      Navigator.pop(context);
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => RestaurantMenuScreen()));
    }
  }

  Widget _deleteBtn() {
    if (editMode) {
      return ElevatedButton(
          onPressed: _delete,
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Text('حذف این محصول'),
          ));
    }
    return Text('');
  }

  void _delete() {
    if (editMode) {
      _service.foods.delete(food);
      Navigator.pop(context);
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => RestaurantMenuScreen()));
    }
  }
}
