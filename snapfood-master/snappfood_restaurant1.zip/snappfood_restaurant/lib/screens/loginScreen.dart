import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../entities/restaurant.dart';
import '../func.dart';
import '../screens/SignupScreen.dart';
import '../service.dart';
import 'dashboardScreen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  Service _service = Service();
  final telController = TextEditingController();
  final passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('اسنپ فود - رستوران'),
        ),
        body: SingleChildScrollView(
          child: Container(
              padding: EdgeInsets.all(60),
              child: Center(
                child: Form(
                    key: _formKey,
                    child: Column(
                      children: <Widget>[
                        TextFormField(
                            controller: telController,
                            decoration: InputDecoration(
                                border: const OutlineInputBorder(),
                                labelText: 'تلفن',
                                hintText: 'تلفن'),
                            validator: (value) {
                              return validateTel(
                                  _service.restaurants, value, false);
                            }),
                        SizedBox(
                          height: 20,
                        ),
                        TextFormField(
                            controller: passwordController,
                            decoration: InputDecoration(
                                border: const OutlineInputBorder(),
                                labelText: 'کلمه عبور',
                                hintText: 'کلمه عبور',
                                suffixIcon: GestureDetector(
                                  dragStartBehavior: DragStartBehavior.down,
                                  onTap: () {
                                    setState(() {
                                      _obscureText = !_obscureText;
                                    });
                                  },
                                  child: Icon(
                                    _obscureText
                                        ? Icons.visibility
                                        : Icons.visibility_off,
                                  ),
                                )),
                            obscureText: _obscureText,
                            validator: (value) {
                              return validatePassword(value);
                            }),
                        SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: ElevatedButton(
                              onPressed: doLogin, child: Text('ورود')),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        TextButton(
                            onPressed: _pushSignup,
                            child: Text('رستوران جدید؟ ثبت نام کنید'))
                      ],
                    )),
              )),
        ));
  }

  void _pushSignup() {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => SignupScreen()));
  }

  void doLogin() {
    if (_formKey.currentState.validate()) {
      List<Restaurant> matches = _service.restaurants.all
          .where((element) =>
              element.tel == telController.text &&
              element.password == passwordController.text)
          .toList();
      if (matches.isNotEmpty) {
        Service _service = Service();
        _service.currentRestaurant = matches[0];

        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => DashboardScreen()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('نام کاربری یا کلمه عبور نادرست است')));
      }
    }
  }
}
