import 'package:flutter/material.dart';

import '../entities/region.dart';
import '../service.dart';

class RegionsCoverageScreen extends StatefulWidget {
  const RegionsCoverageScreen({Key key}) : super(key: key);

  @override
  _RegionsCoverageScreenState createState() => _RegionsCoverageScreenState();
}

class _RegionsCoverageScreenState extends State<RegionsCoverageScreen> {
  List<Region> _regions = [];
  List<Region> _currentRegion = [];
  Service _service = Service();

  @override
  void initState() {
    _regions.addAll(_service.regions.all);
    if (_service.currentRestaurant != null &&
        _service.currentRestaurant.serviceCoverages != null) {
      _currentRegion.addAll(_service.currentRestaurant.serviceCoverages);
    }

    super.initState();
  }



  @override
  void dispose() {
    _service.currentRestaurant.serviceCoverages = _currentRegion;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('ویرایش منو'),
        ),
        body: Container(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: ListView.builder(
                itemCount: _regions.length,
                itemBuilder: (BuildContext context, int index) {
                  return _regionItem(_regions[index], index);
                }),
          ),
        ));
  }

  Widget _regionItem(Region region, int index) {
    bool _thisRegionIncluded = _currentRegion.indexOf(region) != -1;

    return SwitchListTile(
      title: Text(region.title),
      value: _thisRegionIncluded,
      onChanged: (bool value) {
        setState(() {
          if (value) {
            _currentRegion.add(region);
          } else {
            _currentRegion.remove(region);
          }
        });
      },
      secondary: const Icon(Icons.place),
    );
  }
}
