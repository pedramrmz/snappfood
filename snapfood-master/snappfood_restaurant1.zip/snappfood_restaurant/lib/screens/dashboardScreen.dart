import 'package:flutter/material.dart';

import 'commentsManagementScreen.dart';
import 'orderManagementScreen.dart';
import 'regionsCoverageScreen.dart';
import 'reportOrderCountScreen.dart';
import 'restaurantMenuScreen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key key}) : super(key: key);

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  Widget build(BuildContext context) {
    List<MenuItem> menuItems = [
      MenuItem('ویرایش منو', Icons.menu_book, () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => RestaurantMenuScreen()));
      }),
      MenuItem('مدیریت نظرات', Icons.comment_bank, () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => CommentsManagementScreen()));
      }),
      MenuItem('محدوده ارسال', Icons.place, () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => RegionsCoverageScreen()));
      }),
      MenuItem('سفارشات', Icons.restaurant, () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => OrderManagementScreen()));
      }),
      MenuItem('گزارش فروش', Icons.report, () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => ReportOrderCountScreen()));
      }),
    ];

    return Scaffold(
        appBar: AppBar(
          title: Text('اسنپ فود - رستوران'),
        ),
        body: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          padding: const EdgeInsets.all(8),
          childAspectRatio: 1,
          children: menuItems.map<Widget>((menuItem) {
            return TappableCard(menuItem: menuItem);
          }).toList(),
        ));
  }
}

class MenuItem {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  MenuItem(this.title, this.icon, this.onTap);
}

class TappableCard extends StatelessWidget {
  const TappableCard({Key key, this.shape, this.menuItem}) : super(key: key);
  final ShapeBorder shape;
  final MenuItem menuItem;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      shape: shape,
      child: InkWell(
        onTap: menuItem.onTap,
        splashColor: Theme.of(context).colorScheme.onSurface.withOpacity(0.12),
        highlightColor: Colors.transparent,
        child: TappableCardContent(
          menuItem: menuItem,
        ),
      ),
    );
  }
}

class TappableCardContent extends StatelessWidget {
  const TappableCardContent({Key key, this.menuItem}) : super(key: key);
  final MenuItem menuItem;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final titleStyle = theme.textTheme.headline6.copyWith(color: Colors.black);

    return Container(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              menuItem.title,
              style: titleStyle,
            ),
            SizedBox(
              height: 20,
            ),
            Icon(
              menuItem.icon,
              size: 40,
              color: Colors.pinkAccent,
            )
          ],
        ));
  }
}
