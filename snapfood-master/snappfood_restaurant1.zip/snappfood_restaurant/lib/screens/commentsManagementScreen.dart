import 'package:flutter/material.dart';

import '../entities/comment.dart';
import '../func.dart';
import '../service.dart';

class CommentsManagementScreen extends StatefulWidget {
  const CommentsManagementScreen({Key key}) : super(key: key);

  @override
  _CommentsManagementScreenState createState() =>
      _CommentsManagementScreenState();
}

class _CommentsManagementScreenState extends State<CommentsManagementScreen> {
  Service _service = Service();
  List<Comment> _comments = [];
  List<bool> _cardVisibility = [];

  @override
  void initState() {
    _comments = _service.comments.all;
    if (_service.currentRestaurant != null)
      _comments = _comments
          .where((element) =>
              element.restaurantId == _service.currentRestaurant.id)
          .toList();

    for (int i = 0; i < _comments.length; i++) {
      _cardVisibility.add(false);
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('مدیریت نظرات'),
        ),
        body: Container(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: ListView.builder(
                itemCount: _comments.length,
                itemBuilder: (BuildContext context, int index) {
                  return _commentItem(_comments[index], index);
                }),
          ),
        ));
  }

  Widget _commentItem(Comment comment, int index) {
    return GestureDetector(
      onTap: () => {},
      child: Card(
          child: Container(
              padding: EdgeInsets.all(12),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(children: [
                      Text(comment.description == null
                          ? ""
                          : comment.description),
                      Spacer(),
                      Text(dateFormat(comment.createdAt))
                    ]),
                    SizedBox(
                      height: 20,
                    ),
                    Row(children: [
                      Icon(
                        comment.approved
                            ? Icons.mark_email_read_outlined
                            : Icons.unsubscribe_outlined,
                        color:
                            comment.approved ? Colors.green : Colors.redAccent,
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        comment.approved ? 'تایید شده' : 'تایید نشده',
                        style: new TextStyle(
                            fontSize: 12,
                            color: comment.approved
                                ? Colors.green
                                : Colors.redAccent),
                      ),
                      Spacer(),
                      Container(
                        padding:
                            EdgeInsets.symmetric(vertical: 3, horizontal: 8),
                        decoration: BoxDecoration(
                            color: Colors.green,
                            borderRadius: BorderRadius.all(Radius.circular(8))),
                        child: Text(
                          comment.rating.toStringAsFixed(2),
                          style: new TextStyle(color: Colors.white),
                        ),
                      )
                    ]),
                    Divider(
                      thickness: 1,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Text(
                              "پاسخ: ",
                              style: new TextStyle(fontSize: 12),
                            ),
                            Text(
                              comment.response == null ? "" : comment.response,
                              style: new TextStyle(color: Colors.blue),
                            ),
                          ],
                        ),
                        TextButton(
                            onPressed: () {
                              setState(() {
                                _cardVisibility[index] =
                                    !_cardVisibility[index];
                              });
                            },
                            child: Text('مدیریت نظر')),
                      ],
                    ),
                    _editCommentBox(comment, index)
                  ]))),
    );
  }

  Widget _editCommentBox(Comment comment, int index) {
    bool isShowEdit = _cardVisibility[index];
    TextEditingController responseController = new TextEditingController();
    responseController.text = comment.response == null ? "" : comment.response;
    if (isShowEdit) {
      return Column(
        children: [
          Divider(thickness: 1,),
          TextFormField(
              controller: responseController,
              onChanged: (value) {
                _comments[index].response = value;
              },
              decoration: InputDecoration(
                  border: const OutlineInputBorder(),
                  labelText: 'پاسخ',
                  hintText: 'پاسخ')),
          SwitchListTile(
            title: const Text('تایید'),
            value: comment.approved,
            onChanged: (bool value) {
              setState(() {
                _comments[index].approved = value;
              });
            },
            secondary: const Icon(Icons.check_circle),
          ),
          TextButton(onPressed: () {
            setState(() {
              _cardVisibility[index] = false;
            });
          }, child: Text("ذخیره پاسخ"))
        ],
      );
    } else {
      return Text('');
    }
  }
}
