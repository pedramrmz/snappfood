import 'package:flutter/material.dart';

import '../entities/food.dart';
import '../entities/foodCategory.dart';
import '../service.dart';
import 'foodEditScreen.dart';

class RestaurantMenuScreen extends StatefulWidget {
  const RestaurantMenuScreen({Key key}) : super(key: key);

  @override
  _RestaurantMenuScreenState createState() {
    return _RestaurantMenuScreenState();
  }
}

class _RestaurantMenuScreenState extends State<RestaurantMenuScreen> {
  Service _service = Service();
  List<Food> _foods;
  List<FoodCategory> _foodCategories = [];
  int _selectedTagIndex = 0;
  final searchController = new TextEditingController();

  @override
  void initState() {
    _resetFood();
    _foodCategories.add(FoodCategory(0, 'همه'));
    _foodCategories.addAll(_service.foodCategories.all);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('ویرایش منو'),
          actions: [
            IconButton(icon: Icon(Icons.add), onPressed: _pushAddFood)
          ],
        ),
        body: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _filterFoodCategories(),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: TextField(
                  controller: searchController,
                  onChanged: (value) => _runFilter(),
                  decoration: InputDecoration(
                      labelText: 'جستجو', suffixIcon: Icon(Icons.search)),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ListView.builder(
                      itemCount: _foods.length,
                      itemBuilder: (BuildContext context, int index) {
                        return _foodItem(_foods[index]);
                      }),
                ),
              ),
            ],
          ),
        ));
  }

  Widget _filterFoodCategories() {
    return Expanded(
      flex: 0,
      child: Container(
        margin: EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0),
        height: 40,
        child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _foodCategories.length,
            itemBuilder: (BuildContext context, int index) {
              return _foodCategoryFilterItem(_foodCategories[index], index);
            }),
      ),
    );
  }

  Widget _foodCategoryFilterItem(FoodCategory foodCategory, int index) {
    return TextButton(
      onPressed: () {
        _selectedTagIndex = index;
        _runFilter();
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Text(
          foodCategory.title,
          style: new TextStyle(
              color:
                  _selectedTagIndex == index ? Colors.green : Colors.blueGrey),
        ),
      ),
    );
  }

  Widget _foodItem(Food food) {
    return GestureDetector(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      FoodEditScreen(food: food, editMode: true)));
        },
        child: Card(
          child: Container(
            padding: EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.asset('assets/images/food.jpg',
                          height: 80, width: 80, repeat: ImageRepeat.noRepeat),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Icon(
                            food.available
                                ? Icons.check_circle
                                : Icons.visibility_off,
                            color: food.available
                                ? Colors.green
                                : Colors.deepOrange),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          food.available ? 'موجود' : 'غیرفعال',
                          style: TextStyle(
                              color: food.available
                                  ? Colors.green
                                  : Colors.deepOrange),
                        )
                      ],
                    )
                  ],
                ),
                Column(
                  children: [
                    SizedBox(
                      width: 10,
                    )
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(food.title),
                    SizedBox(
                      height: 5,
                    ),
                    Text(food.description,
                        style: new TextStyle(
                            color: Colors.blueGrey, fontSize: 12)),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      'قیمت: ' + food.price.toString(),
                      style:
                          new TextStyle(color: Colors.redAccent, fontSize: 12),
                    )
                  ],
                )
              ],
            ),
          ),
        ));
  }

  void _pushAddFood() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => FoodEditScreen(
                food: new Food(null, null, null, 0, true, null, null),
                editMode: false)));
  }

  _runFilter() {
    String value = searchController.text;
    setState(() {
      _resetFood();
      if (value.trim().isNotEmpty) {
        _foods = _foods
            .where((element) => element.title
                .toLowerCase()
                .contains(value.trim().toLowerCase()))
            .toList();
      }

      if (_selectedTagIndex > 0) {
        int categoryId = _foodCategories[_selectedTagIndex].id;
        _foods = _foods
            .where((element) => element.foodCategory.id == categoryId)
            .toList();
      }
    });
  }

  void _resetFood() {
    _foods = _service.foods.all;
    if (_service.currentRestaurant != null) {
      _foods = _foods
          .where((element) =>
              element.restaurantId == _service.currentRestaurant.id)
          .toList();
    }
  }
}
