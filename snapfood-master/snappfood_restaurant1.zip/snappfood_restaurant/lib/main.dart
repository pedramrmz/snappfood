import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'feedContainers.dart';
import 'screens/commentsManagementScreen.dart';
import 'screens/dashboardScreen.dart';
import 'screens/loginScreen.dart';
import 'screens/orderManagementScreen.dart';
import 'screens/regionsCoverageScreen.dart';
import 'screens/reportOrderCountScreen.dart';
import 'screens/restaurantMenuScreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final String _title = 'اسنپ فود - رستوران';

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    FeedContainers feedContainers = new FeedContainers();
    return MaterialApp(
        localizationsDelegates: [
          GlobalCupertinoLocalizations.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
        ],
        supportedLocales: [
          Locale("fa", "IR"),
        ],
        locale: Locale("fa", "IR"),
        title: _title,
        theme: ThemeData(
          primarySwatch: Colors.pink,
        ),
        // home: LoginScreen(restaurants: restaurants),
        initialRoute: '/',
        routes: {
          '/': (context) => LoginScreen(),
          '/dashboard': (context) => DashboardScreen(),
          '/menu': (context) => RestaurantMenuScreen(),
          '/comments': (context) => CommentsManagementScreen(),
          '/coverage': (context) => RegionsCoverageScreen(),
          '/orders': (context) => OrderManagementScreen(),
          '/report-sales': (context) => ReportOrderCountScreen(),
        });
  }
}
