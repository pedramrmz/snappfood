import '../entities/region.dart';
import 'baseContainer.dart';

class RegionContainer extends BaseContainer<Region> {}
