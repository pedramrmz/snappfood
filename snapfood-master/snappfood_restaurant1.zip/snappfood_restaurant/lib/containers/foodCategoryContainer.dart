import 'package:snappfood_restaurant/entities/foodCategory.dart';

import 'baseContainer.dart';

class FoodCategoryContainer extends BaseContainer<FoodCategory> {
  FoodCategoryContainer() {
    this.add(FoodCategory(1, 'برنجی'));
    this.add(FoodCategory(2, 'صبحانه'));
    this.add(FoodCategory(3, 'پیتزا'));
    this.add(FoodCategory(4, 'سوخاری'));
    this.add(FoodCategory(5, 'ایتالیایی'));
    this.add(FoodCategory(6, 'نوشیدنی'));
    this.add(FoodCategory(7, 'پیش غذا'));
    this.add(FoodCategory(8, 'سالاد'));
  }
}
