import 'package:snappfood_restaurant/entities/restaurantCategory.dart';

import 'baseContainer.dart';

class RestaurantCategoryContainer extends BaseContainer<RestaurantCategory> {
  RestaurantCategoryContainer() {
    this.add(RestaurantCategory(1, 'ایرانی'));
    this.add(RestaurantCategory(2, 'دریایی'));
    this.add(RestaurantCategory(3, 'فست فود'));
    this.add(RestaurantCategory(3, 'ایتالیایی'));
  }
}
