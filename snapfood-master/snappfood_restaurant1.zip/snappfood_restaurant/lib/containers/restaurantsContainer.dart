import 'package:snappfood_restaurant/entities/restaurant.dart';

import 'baseContainer.dart';

class RestaurantsContainer extends BaseContainer<Restaurant> {
  Restaurant getByTel(String tel) {
    try {
      Restaurant found = all.firstWhere((element) => tel == element.tel);
      return found;
    } catch (e) {}
    return null;
  }

  @override
  void add(Restaurant restaurant) {
    if (restaurant == null || restaurant.tel == null) return;

    Restaurant found = getByTel(restaurant.tel);
    if (found == null) all.add(restaurant);
  }
}
