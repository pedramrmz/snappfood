import 'package:snappfood_restaurant/entities/orderItem.dart';

import 'baseContainer.dart';

class OrderItemContainer extends BaseContainer<OrderItem> {}
