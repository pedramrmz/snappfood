import 'package:snappfood_restaurant/entities/comment.dart';

import 'baseContainer.dart';

class CommentContainer extends BaseContainer<Comment> {}
