import 'package:snappfood_restaurant/entities/order.dart';

import 'baseContainer.dart';

class OrderContainer extends BaseContainer<Order> {}
