import 'package:snappfood_restaurant/entities/baseEntity.dart';

abstract class BaseContainer<E extends BaseEntity> {
  final List<E> all = [];

  E get(int id) {
    try {
      E found = all.firstWhere((element) => id == element.id);
      return found;
    } catch (e) {}
    return null;
  }

  void add(E item) {
    if (item == null || item.id == null) return;

    E found = get(item.id);
    if (found == null) all.add(item);
  }

  void update(E entity) {
    try {
      E found = all.firstWhere((element) => entity.id == element.id);
      int index = all.indexOf(found);
      all[index] = entity;
    } catch (e) {}
  }

  void delete(E entity) {
    try {
      E found = all.firstWhere((element) => entity.id == element.id);
      int index = all.indexOf(found);
      all.removeAt(index);
    } catch (e) {}
  }
}
