import 'package:snappfood_restaurant/entities/customer.dart';

import 'baseContainer.dart';

class CustomerContainer extends BaseContainer<Customer> {}
