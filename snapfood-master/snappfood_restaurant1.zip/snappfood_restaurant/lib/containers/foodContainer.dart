import 'package:snappfood_restaurant/entities/food.dart';

import 'baseContainer.dart';

class FoodContainer extends BaseContainer<Food> {}
