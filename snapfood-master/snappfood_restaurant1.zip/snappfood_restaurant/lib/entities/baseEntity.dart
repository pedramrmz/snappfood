class BaseEntity {
  int id;
}
