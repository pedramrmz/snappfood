import 'baseEntity.dart';

class Region extends BaseEntity {
  int id;
  String title;
  double latitude;
  double longitude;

  Region(this.id, this.title, {this.latitude, this.longitude});
}
