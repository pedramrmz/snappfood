import 'baseEntity.dart';
import 'customer.dart';
import 'orderItem.dart';

class Order extends BaseEntity {
  int id;
  int restaurantId;
  Customer customer;
  List<OrderItem> items;
  DateTime orderDateTime;
  DateTime actionDateTime;
  double orderPrice;
  String description;
  OrderStatus orderStatus;
  String deliveryAddress;
  String trackingCode;

  Order(
      this.id,
      this.restaurantId,
      this.customer,
      this.items,
      this.orderDateTime,
      this.actionDateTime,
      this.orderPrice,
      this.description,
      this.orderStatus,
      this.deliveryAddress,
      this.trackingCode);
}

enum OrderStatus { received, preparing, delivered }
