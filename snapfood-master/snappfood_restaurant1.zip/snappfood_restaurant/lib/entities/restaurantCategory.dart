import 'baseEntity.dart';

class RestaurantCategory extends BaseEntity {
  int id;
  String title;

  RestaurantCategory(this.id, this.title);
}
