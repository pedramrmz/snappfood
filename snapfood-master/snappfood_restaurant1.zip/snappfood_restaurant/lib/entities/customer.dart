import 'baseEntity.dart';

class Customer extends BaseEntity {
  int id;
  String firstName;
  String lastName;
  String address;
  String mobile;

  Customer(this.id, this.firstName, this.lastName, this.address, this.mobile);
}
