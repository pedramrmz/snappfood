import 'baseEntity.dart';
import 'foodCategory.dart';

class Food extends BaseEntity {
  int id;
  String title;
  String description;
  double price;
  bool available;
  FoodCategory foodCategory;
  int restaurantId;

  Food(this.id, this.title, this.description, this.price, this.available,
      this.foodCategory, this.restaurantId);
}
