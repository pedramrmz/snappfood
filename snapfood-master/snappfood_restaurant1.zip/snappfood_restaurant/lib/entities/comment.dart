import 'baseEntity.dart';
import 'customer.dart';

class Comment extends BaseEntity {
  int id;
  Customer customer;
  int orderId;
  int restaurantId;
  String description;
  int rating;
  DateTime createdAt;
  bool approved;
  String response;

  Comment(
      this.id,
      this.customer,
      this.orderId,
      this.restaurantId,
      this.description,
      this.rating,
      this.createdAt,
      this.approved,
      this.response);
}
