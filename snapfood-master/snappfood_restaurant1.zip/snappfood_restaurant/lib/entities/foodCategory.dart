import 'baseEntity.dart';

class FoodCategory extends BaseEntity {
  int id;
  String title;

  FoodCategory(this.id, this.title);
}
