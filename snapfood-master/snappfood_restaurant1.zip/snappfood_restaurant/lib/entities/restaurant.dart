import 'package:snappfood_restaurant/entities/restaurantCategory.dart';

import 'baseEntity.dart';
import 'region.dart';

class Restaurant extends BaseEntity {
  int id;
  String title;
  String address;
  RestaurantCategory category;
  String tel;
  String password;
  List<Region> serviceCoverages;

  Restaurant(
      {this.id,
      this.title,
      this.address,
      this.category,
      this.tel,
      this.password,
      this.serviceCoverages});
}
