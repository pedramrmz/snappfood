import 'baseEntity.dart';
import 'food.dart';

class OrderItem extends BaseEntity {
  int id;
  Food food;
  double qty;
  double pricePerItem;
  double priceTotal;

  OrderItem(this.id, this.food, this.qty, this.pricePerItem, this.priceTotal);
}
