import 'package:snappfood_restaurant/entities/region.dart';

import 'entities/comment.dart';
import 'entities/customer.dart';
import 'entities/food.dart';
import 'entities/order.dart';
import 'entities/orderItem.dart';
import 'entities/restaurant.dart';
import 'service.dart';

class FeedContainers {
  FeedContainers() {
    Service _service = Service();

    _service.regions.add(Region(1, "منطقه یک"));
    _service.regions.add(Region(2, "منطقه دو"));
    _service.regions.add(Region(3, "منطقه سه"));
    _service.regions.add(Region(4, "منطقه چهار"));
    _service.regions.add(Region(5, "منطقه پنج"));
    _service.regions.add(Region(6, "منطقه شش"));
    _service.regions.add(Region(7, "منطقه هفت"));

    _service.restaurants.add(Restaurant(
        id: 1,
        title: 'رستوران یک',
        address: 'آدرس رستوران اول',
        category: _service.restaurantCategories.get(1),
        tel: '09121234567',
        password: 'a111111',
        serviceCoverages: [_service.regions.get(1), _service.regions.get(2)]));

    _service.restaurants.add(Restaurant(
        id: 2,
        title: 'رستوران دو',
        address: 'آدرس رستوران دوم',
        category: _service.restaurantCategories.get(3),
        tel: '09129876543',
        password: 'a111111',
        serviceCoverages: [_service.regions.get(2), _service.regions.get(3)]));

    _service.foods.add(Food(1, "غذای یک", "توضیحات غذای یک", 12000, true,
        _service.foodCategories.get(1), 1));
    _service.foods.add(Food(2, "غذای دو", "توضیحات غذای دو", 23000, false,
        _service.foodCategories.get(2), 1));
    _service.foods.add(Food(3, "غذای سه", "توضیحات غذای سه", 34000, true,
        _service.foodCategories.get(3), 1));
    _service.foods.add(Food(4, "غذای چهار", "توضیحات غذای چهار", 45000, true,
        _service.foodCategories.get(4), 1));
    _service.foods.add(Food(5, "غذای پنج", "توضیحات غذای پنج", 56000, false,
        _service.foodCategories.get(5), 1));
    _service.foods.add(Food(6, "غذای شش", "توضیحات غذای شش", 67000, true,
        _service.foodCategories.get(1), 1));
    _service.foods.add(Food(7, "غذای هفت", "توضیحات غذای هفت", 78000, true,
        _service.foodCategories.get(2), 1));
    _service.foods.add(Food(8, "غذای یک رستوران 2", "توضیحات غذای یک", 12000,
        true, _service.foodCategories.get(2), 2));

    _service.customers
        .add(Customer(1, 'مشتری', 'یک', 'آدرس مشتری', '09121234568'));
    _service.customers
        .add(Customer(2, 'مشتری', 'دو', 'آدرس مشتری', '09121234568'));
    _service.customers
        .add(Customer(3, 'مشتری', 'سه', 'آدرس مشتری', '09121234568'));
    _service.customers
        .add(Customer(4, 'مشتری', 'چهار', 'آدرس مشتری', '09121234568'));

    _service.comments.add(Comment(1, _service.customers.get(1), 1, 1,
        "غدا دیر رسید", 3, new DateTime.now(), false, null));

    _service.comments.add(Comment(
        2,
        _service.customers.get(2),
        2,
        1,
        "عالی و خوشمزه بود تشکر",
        5,
        new DateTime.now(),
        true,
        "با تشکر نوش جان"));

    _service.orders.add(Order(
        1,
        1,
        _service.customers.get(1),
        [
          new OrderItem(1, _service.foods.get(1), 2, 12000, 24000),
          new OrderItem(2, _service.foods.get(2), 2, 23000, 23000),
        ],
        DateTime(2021, 5, 12, 22, 00, 10),
        null,
        47000,
        "لطفا قاشق چنگال یکبار مصرف همراه غدا باشد",
        OrderStatus.preparing,
        "آدرس", "order123468"));

    _service.orders.add(Order(
        2,
        1,
        _service.customers.get(2),
        [
          new OrderItem(3, _service.foods.get(3), 1, 34000, 34000),
          new OrderItem(4, _service.foods.get(4), 3, 45000, 135000),
        ],
        DateTime(2021, 5, 21, 22, 00, 10),
        null,
        169000,
        null,
        OrderStatus.received,
        "آدرس", "order323571"));
  }
}
