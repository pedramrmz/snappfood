public class User {
    User(String name,String lastname,String adress,String tel,String pass){
       this.name=name;
       this.lastname=lastname;
       this.adress=adress;
       this.tell=tel;
       this.pass=pass;
    }
public String tell;
public String pass;
public String name;
public String lastname;
public String adress;
}
