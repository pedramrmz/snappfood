enum Type{
  breakfast,persian,fried,see,fastfood,
}