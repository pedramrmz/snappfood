import java.util.ArrayList;

public class Database {
    public ArrayList<User> users=new ArrayList<>();

    public boolean finduser(String pass,String tel){
     for (int i=0;i< users.size();++i) {
            User u= users.get(i);
    if(u.pass.equals(pass) && u.tell.equals(tel))
        return true;
        }
        return false;
    }
    public User getUser(String pass,String tel){
        for (int i=0;i< users.size();++i) {
            User u= users.get(i);
            if(u.pass.equals(pass) && u.tell.equals(tel))
                return u;
        }
        System.out.println("is not found");
        return null;
    }
}
