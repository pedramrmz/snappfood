import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class ClientHandler extends Thread{
    Socket s;
    DataInputStream dis;
    DataOutputStream dos;
    Database database;

    ClientHandler(Socket cs,Database database){
        this.s=cs;
        this.database=database;
    }

    public void run(){
        try {
            DataInputStream dataInputStream;
            DataOutputStream dataOutputStream;
            dataInputStream=new DataInputStream(s.getInputStream());
            dataOutputStream=new DataOutputStream(s.getOutputStream());

            String command=dataInputStream.readLine();
            System.out.println(command);
            if(command.equals("Login")){
                String pass=dataInputStream.readLine();
                String tel=dataInputStream.readLine();
                System.out.println(pass + tel);
                if(Login(tel,pass)){
                    dataOutputStream.writeBytes("true ");
                    User u=database.getUser(pass,tel);
                    dataOutputStream.writeBytes(u.name+" ");
                    dataOutputStream.writeBytes(u.lastname+" ");
                    dataOutputStream.writeBytes(u.adress+" ");
                }
                else{
                    dataOutputStream.writeBytes("false ");
                }
            }
            else if(command.equals("Signup")){
                String name=dataInputStream.readLine();
                String lastname=dataInputStream.readLine();
                String address=dataInputStream.readLine();
                String tel=dataInputStream.readLine();
                String pass=dataInputStream.readLine();
                System.out.println(name+lastname+address+tel+pass+"+");
                User user=new User(name,lastname,address,tel,pass);
                this.database.users.add(user);
                dataOutputStream.writeBytes(name+" is signed up");

            }else if(command.equals("Buy")){

            }

            dataInputStream.close();
            dataOutputStream.close();
            s.close();
        }catch (Exception e){
            e.printStackTrace();}

        System.out.println("Client Exited");
    }

    public boolean Login(String tel,String pass){
        boolean response=database.finduser(pass,tel);
        return response;
    }
}
public class Main {
    public static void main (String[] args) throws IOException{
        ServerSocket ss=new ServerSocket(1302);
        System.out.println("server created");
        Database database=new Database();
        while (true){
            Socket cs=ss.accept();
            System.out.println("client connected");
            ClientHandler newClient=new ClientHandler(cs,database);
            newClient.start();
        }
    }
}
